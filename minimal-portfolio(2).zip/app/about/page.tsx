import type { Metadata } from "next"
import { RotatingBackground } from "@/components/rotating-background"
import { ArrowDown } from "lucide-react"

export const metadata: Metadata = {
  title: "About",
  description: "Backend engineer crafting resilient, modular systems in Go and Java.",
}

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <RotatingBackground />

        <div className="container relative z-10 text-center">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold tracking-tight mb-8 leading-none">
              about
              <br />
              <span className="text-muted-foreground">me</span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto mb-12 leading-relaxed">
              Backend engineer crafting resilient, modular systems and electronic music.
            </p>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ArrowDown className="h-6 w-6 text-muted-foreground" />
        </div>
      </section>

      {/* Content Section */}
      <section className="py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
            <div className="md:col-span-1">
              <h2 className="text-3xl font-bold tracking-tight mb-6">My Story</h2>
            </div>
            <div className="md:col-span-2 space-y-6">
              <p className="text-muted-foreground leading-relaxed">
                Hey — I'm Samin Tejas. I write fast backend systems, build my own tools, and customize everything down
                to the window manager.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                By profession, I'm a backend engineer who crafts resilient, modular systems in Go and Java — shipping
                production-grade microservices for real-world scale. But that's just the surface.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                I don't just code — I engineer ecosystems. I've built static site generators, markdown-based note
                systems, custom Linux environments, and productivity-first tooling from scratch. I automate what others
                tolerate. I tweak pixels, write my own shell scripts, and fork window managers to fit my workflow like a
                glove.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Outside of code, I produce ambient and modular electronic music as Stellarmantra — because good systems
                should sound as smooth as they run.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                No fluff. Just clean code, efficient systems, and a deep love for the craft.
              </p>

              <h2 className="text-2xl font-bold tracking-tight mt-12 mb-6">Skills</h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-bold mb-3">Languages</h3>
                  <ul className="space-y-3">
                    <li className="flex items-center justify-between">
                      <span>Go</span>
                      <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[95%]"></div>
                      </div>
                    </li>
                    <li className="flex items-center justify-between">
                      <span>Java</span>
                      <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[90%]"></div>
                      </div>
                    </li>
                    <li className="flex items-center justify-between">
                      <span>TypeScript</span>
                      <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[85%]"></div>
                      </div>
                    </li>
                    <li className="flex items-center justify-between">
                      <span>Python</span>
                      <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[80%]"></div>
                      </div>
                    </li>
                    <li className="flex items-center justify-between">
                      <span>Rust</span>
                      <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[70%]"></div>
                      </div>
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-bold mb-3">Technologies</h3>
                  <ul className="space-y-3">
                    <li className="flex items-center justify-between">
                      <span>Microservices</span>
                      <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[95%]"></div>
                      </div>
                    </li>
                    <li className="flex items-center justify-between">
                      <span>Docker/Kubernetes</span>
                      <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[90%]"></div>
                      </div>
                    </li>
                    <li className="flex items-center justify-between">
                      <span>Linux</span>
                      <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[95%]"></div>
                      </div>
                    </li>
                    <li className="flex items-center justify-between">
                      <span>gRPC</span>
                      <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[85%]"></div>
                      </div>
                    </li>
                    <li className="flex items-center justify-between">
                      <span>Distributed Systems</span>
                      <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[90%]"></div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>

              <h2 className="text-2xl font-bold tracking-tight mt-12 mb-6">Experience</h2>

              <div className="space-y-8">
                <div className="border-l-2 border-muted pl-6 relative">
                  <div className="absolute w-3 h-3 bg-primary rounded-full -left-[7px] top-1"></div>
                  <h3 className="text-lg font-bold">Senior Backend Engineer</h3>
                  <p className="text-sm text-muted-foreground mb-2">TechCorp Inc. • 2021 - Present</p>
                  <p className="text-muted-foreground">
                    Leading the development of a distributed microservices architecture using Go and Kubernetes.
                    Implemented fault-tolerant systems with 99.99% uptime.
                  </p>
                </div>

                <div className="border-l-2 border-muted pl-6 relative">
                  <div className="absolute w-3 h-3 bg-primary rounded-full -left-[7px] top-1"></div>
                  <h3 className="text-lg font-bold">Backend Developer</h3>
                  <p className="text-sm text-muted-foreground mb-2">DataSystems • 2018 - 2021</p>
                  <p className="text-muted-foreground">
                    Developed and maintained Java-based backend services for high-traffic applications. Optimized
                    database queries resulting in 40% performance improvement.
                  </p>
                </div>

                <div className="border-l-2 border-muted pl-6 relative">
                  <div className="absolute w-3 h-3 bg-primary rounded-full -left-[7px] top-1"></div>
                  <h3 className="text-lg font-bold">Software Engineer</h3>
                  <p className="text-sm text-muted-foreground mb-2">StartupX • 2016 - 2018</p>
                  <p className="text-muted-foreground">
                    Full-stack development with focus on backend systems. Implemented RESTful APIs and real-time data
                    processing pipelines.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
